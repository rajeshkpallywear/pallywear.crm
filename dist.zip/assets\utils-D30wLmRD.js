import{bV as I,c as N}from"./vendor-core-C3qPMscN.js";function T(...e){return I(N(e))}function D(e){if(!e)return"General";if(typeof e=="string")return e.trim()||"General";if(e.sizeBreakdown&&Array.isArray(e.sizeBreakdown)&&e.sizeBreakdown.length>0){const a=Array.from(new Set(e.sizeBreakdown.map(o=>(o==null?void 0:o.category)||(o==null?void 0:o.name)).filter(Boolean)));if(a.length===1)return a[0]||"General";if(a.length>1)return"Mixed Order"}return e.category||"General"}function A(e){try{if(!e)return 0;const a=typeof e=="string"?e:JSON.stringify(e);return a?a.length:0}catch{return 0}}function O(e,a=0){try{const r=A(e)+a,s=500*1024*1024;return r>s?(console.warn(`Order size validation warning: ${(r/(1024*1024)).toFixed(1)}MB exceeds limit`),!1):!0}catch{return!0}}function W(e){var a,o,r,s;try{const i=e.customerInfo||{};let c=(i.phone||e.customerPhone||e.phone||"").toString().trim();if(!c){const t=prompt(`Enter the customer's WhatsApp phone number (with country code, e.g. 919876543210):

Leave empty to pick contact inside WhatsApp:`,"");if(t===null)return;c=t.trim()}const d=e.sizeBreakdown&&e.sizeBreakdown.length>0?e.sizeBreakdown.map(t=>`• ${t.category||e.category||"Item"}: ${t.size||"Standard"} (Qty: ${t.quantity||1}) - ₹${((t.price||0)*(t.quantity||1)).toLocaleString("en-IN")}${t.colour?` | ${t.colour}`:""}${t.printType?` | ${t.printType}`:""}`).join(`
`):`• ${e.category||"Order"} - Qty: ${e.quantity||1}`,l=Number(((a=e.financials)==null?void 0:a.totalAmount)??e.totalAmount??0),p=Number(((o=e.financials)==null?void 0:o.advancePay)??e.advancePay??0),u=Number(((r=e.financials)==null?void 0:r.balanceAmount)??e.balanceAmount??Math.max(0,l-p)),n=Math.round(l*.5),f=l,m=String(e.id||"").replace(/^#/,"").trim(),w=m.length>6?m.slice(-6).toUpperCase():m.toUpperCase(),y=typeof window<"u"&&((s=window.location)!=null&&s.origin)?window.location.origin:"https://pallywear.com",$=`${y}/pay/${encodeURIComponent(m)}?pct=50`,b=`${y}/pay/${encodeURIComponent(m)}?pct=100`,g=`Hello *${i.name||e.customerName||i.contactPerson||"Valued Customer"}*,

Thank you for your order with *Pallywear*!

📦 *Order Details:* #${w}
━━━━━━━━━━━━━━━━━━━
• *Category:* ${e.category||"Apparel"}
• *Total Quantity:* ${e.quantity||1} units
• *Status:* ${String(e.status||"Received").toUpperCase()}
━━━━━━━━━━━━━━━━━━━
📋 *Items / Breakdown:*
${d}
━━━━━━━━━━━━━━━━━━━
💰 *Financial Summary:*
• Total Amount: ₹${l.toLocaleString("en-IN")}
• 50% : ₹${n.toLocaleString("en-IN")}
👉 Pay 50% Online: ${$}

• 100 %: ₹${f.toLocaleString("en-IN")}
👉 Pay 100% Online: ${b}
`+(p>0?`
• Paid Amount: ₹${p.toLocaleString("en-IN")}
• Pending Pay: ₹${u.toLocaleString("en-IN")}
`:"")+`━━━━━━━━━━━━━━━━━━━

We are processing your order. For any queries, feel free to reply directly to this message.`;let h="";if(c){let t=c.replace(/[^\d+]/g,"");t.length===10&&!t.startsWith("+")?t="91"+t:t.startsWith("+")&&(t=t.substring(1)),h=`https://wa.me/${t}?text=${encodeURIComponent(g)}`}else h=`https://api.whatsapp.com/send?text=${encodeURIComponent(g)}`;window.open(h,"_blank")}catch(i){console.error("Error sharing order to WhatsApp:",i),alert("Could not open WhatsApp sharing. Please check order details.")}}const S="Quotation price is final with 50% advance required to confirm the order and the remaining 50% payable before shipment. The customer must verify and approve the Pallywear Order Confirmation, including all details and final mockup via Email or WhatsApp before payment and production, as the customer is responsible for confirming size, quantity, colour, design, spelling, print details, and mockup (Pallywear is not responsible for customer-approved errors). Due to fabric, printing, and production limitations, Jersey and Embroidery output may be approximately 80% similar to the approved design/mockup and 100% exact reproduction cannot be guaranteed, while errors caused by Pallywear will be reviewed and resolved appropriately. Production commences upon approval and advance payment with a tentative delivery timeline of 7–10 working days subject to production and logistics, and for bulk orders, one sample piece will be confirmed and approved by the customer before bulk production.";function z(e){var a;try{const o=(e.billToPhone||e.customerPhoneNumber||"").trim(),r=prompt(`Enter the WhatsApp phone number (with country code, e.g. 919876543210) to share this invoice.

Leave empty to pick any contact directly inside WhatsApp:`,o);if(r===null)return;const s=r.trim(),i=e.items&&e.items.length>0?e.items.map(n=>`• ${n.description||"Item"} (Qty: ${n.quantity||1}) - ₹${Number(n.amount||n.rate*n.quantity||0).toLocaleString("en-IN")}`).join(`
`):`• ${((a=e.productType)==null?void 0:a.toUpperCase())||"Product"} (Qty: 1)`,c=Number(e.total||0),d=e.dueDate?new Date(e.dueDate).toLocaleDateString("en-IN"):"On Demand",l=(e.termsAndConditions||S).trim(),p=`Hello *${e.billToName||"Customer"}*,

This is a message from *${e.fromName||"Pallywear Gifting Solutions"}*.

Here are the details for your Invoice *#${e.invoiceNumber||"NEW"}*:
━━━━━━━━━━━━━━━━━━━
• *Total Amount:* ₹${c.toLocaleString("en-IN")}
• *Due Date:* ${d}
• *Payment Method:* ${e.paymentMethod||"GPay"}
`+(i?`━━━━━━━━━━━━━━━━━━━
• *Items:*
${i}
`:"")+`━━━━━━━━━━━━━━━━━━━
📜 *TERMS & CONDITIONS:*
${l}
━━━━━━━━━━━━━━━━━━━

Please proceed with the payment. Thank you for choosing Pallywear!`;let u="";if(s){let n=s.replace(/[^\d+]/g,"");n.length===10&&!n.startsWith("+")?n="91"+n:n.startsWith("+")&&(n=n.substring(1)),u=`https://wa.me/${n}?text=${encodeURIComponent(p)}`}else u=`https://api.whatsapp.com/send?text=${encodeURIComponent(p)}`;window.open(u,"_blank")}catch(o){console.error("Error sharing invoice to WhatsApp:",o),alert("Could not open WhatsApp sharing. Please check invoice details.")}}export{S as D,W as a,T as c,D as g,O as i,z as s};
