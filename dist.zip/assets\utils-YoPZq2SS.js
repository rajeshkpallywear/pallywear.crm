import{bV as g,c as d}from"./vendor-core-CNeDRc5b.js";function w(...t){return g(d(t))}function A(t){if(!t)return"General";if(typeof t=="string")return t.trim()||"General";if(t.sizeBreakdown&&Array.isArray(t.sizeBreakdown)&&t.sizeBreakdown.length>0){const a=Array.from(new Set(t.sizeBreakdown.map(o=>(o==null?void 0:o.category)||(o==null?void 0:o.name)).filter(Boolean)));if(a.length===1)return a[0]||"General";if(a.length>1)return"Mixed Order"}return t.category||"General"}function f(t){try{if(!t)return 0;const a=typeof t=="string"?t:JSON.stringify(t);return a?a.length:0}catch{return 0}}function S(t,a=0){try{const s=f(t)+a,r=500*1024*1024;return s>r?(console.warn(`Order size validation warning: ${(s/(1024*1024)).toFixed(1)}MB exceeds limit`),!1):!0}catch{return!0}}function I(t){var a,o,s;try{const r=t.customerInfo||{},c=(r.phone||t.customerPhone||"").trim(),l=prompt(`Enter the WhatsApp phone number (with country code, e.g. 919876543210) to share this order.

Leave empty to pick any contact directly inside WhatsApp:`,c);if(l===null)return;const p=l.trim(),u=t.sizeBreakdown&&t.sizeBreakdown.length>0?t.sizeBreakdown.map(n=>`• ${n.category||"Item"}: ${n.size||"Standard"} (Qty: ${n.quantity||1}) - ₹${((n.price||0)*(n.quantity||1)).toLocaleString("en-IN")}${n.colour?` | ${n.colour}`:""}${n.printType?` | ${n.printType}`:""}`).join(`
`):`• ${t.category||"Order"} - Qty: ${t.quantity||1}`,i=((a=t.financials)==null?void 0:a.totalAmount)??t.totalAmount??0,e=((o=t.financials)==null?void 0:o.advancePay)??t.advancePay??0,y=((s=t.financials)==null?void 0:s.balanceAmount)??t.balanceAmount??i-e,m=`Hello *${r.name||"Valued Customer"}*,

Thank you for your order with *Pallywear*!

📦 *Order Details:* #${String(t.id).slice(-6).toUpperCase()}
━━━━━━━━━━━━━━━━━━━
• *Category:* ${t.category||"Apparel"}
• *Total Quantity:* ${t.quantity||1} units
• *Status:* ${String(t.status||"Received").toUpperCase()}
━━━━━━━━━━━━━━━━━━━
📋 *Items / Breakdown:*
${u}
━━━━━━━━━━━━━━━━━━━
💰 *Financial Summary:*
• Total Amount: ₹${Number(i).toLocaleString("en-IN")}
`+(e>0?`• Advance Paid: ₹${Number(e).toLocaleString("en-IN")}
`:"")+`• Balance Due: ₹${Number(y).toLocaleString("en-IN")}
━━━━━━━━━━━━━━━━━━━

We are processing your order. For any queries, feel free to reply directly to this message.`;let h="";if(p){let n=p.replace(/[^\d+]/g,"");n.length===10&&!n.startsWith("+")?n="91"+n:n.startsWith("+")&&(n=n.substring(1)),h=`https://wa.me/${n}?text=${encodeURIComponent(m)}`}else h=`https://api.whatsapp.com/send?text=${encodeURIComponent(m)}`;window.open(h,"_blank")}catch(r){console.error("Error sharing order to WhatsApp:",r),alert("Could not open WhatsApp sharing. Please check order details.")}}function b(t){var a;try{const o=(t.billToPhone||t.customerPhoneNumber||"").trim(),s=prompt(`Enter the WhatsApp phone number (with country code, e.g. 919876543210) to share this invoice.

Leave empty to pick any contact directly inside WhatsApp:`,o);if(s===null)return;const r=s.trim(),c=t.items&&t.items.length>0?t.items.map(e=>`• ${e.description||"Item"} (Qty: ${e.quantity||1}) - ₹${Number(e.amount||e.rate*e.quantity||0).toLocaleString("en-IN")}`).join(`
`):`• ${((a=t.productType)==null?void 0:a.toUpperCase())||"Product"} (Qty: 1)`,l=Number(t.total||0),p=t.dueDate?new Date(t.dueDate).toLocaleDateString("en-IN"):"On Demand",u=`Hello *${t.billToName||"Customer"}*,

This is a message from *${t.fromName||"Pallywear Gifting Solutions"}*.

Here are the details for your Invoice *#${t.invoiceNumber||"NEW"}*:
━━━━━━━━━━━━━━━━━━━
• *Total Amount:* ₹${l.toLocaleString("en-IN")}
• *Due Date:* ${p}
• *Payment Method:* ${t.paymentMethod||"GPay"}
`+(c?`━━━━━━━━━━━━━━━━━━━
• *Items:*
${c}
`:"")+`━━━━━━━━━━━━━━━━━━━

Please proceed with the payment. Thank you for choosing Pallywear!`;let i="";if(r){let e=r.replace(/[^\d+]/g,"");e.length===10&&!e.startsWith("+")?e="91"+e:e.startsWith("+")&&(e=e.substring(1)),i=`https://wa.me/${e}?text=${encodeURIComponent(u)}`}else i=`https://api.whatsapp.com/send?text=${encodeURIComponent(u)}`;window.open(i,"_blank")}catch(o){console.error("Error sharing invoice to WhatsApp:",o),alert("Could not open WhatsApp sharing. Please check invoice details.")}}export{I as a,w as c,A as g,S as i,b as s};
